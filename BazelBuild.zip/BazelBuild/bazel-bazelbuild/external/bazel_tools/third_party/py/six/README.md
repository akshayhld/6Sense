[six](https://pythonhosted.org/six/)
------

* Version: 1.12.0
* License: MIT
* From: [https://pypi.python.org/packages/source/s/six/six-1.12.0.tar.gz](https://pypi.python.org/packages/source/s/six/six-1.12.0.tar.gz)
